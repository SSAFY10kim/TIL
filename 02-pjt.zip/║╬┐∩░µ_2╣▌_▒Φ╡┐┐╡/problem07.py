############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def sum_primes(number):
    # pass
    # 여기에 코드를 작성하여 함수를 완성합니다.
    prime = [2]                 # 소수 리스트(2는 미리 추가)
    ans = 0                     # 소수의 합 변수

    for i in range(3, number):  # 3부터 number미만까지 범위에서
        lst = []    # 나머지 반환 리스트
        for j in range(2,i):    # i보다 작은 수들로 나눈 나머지를
            lst.append(i%j)     # 리스트에 반환
        if 0 not in lst:        # 나머지 리스트에 0이 하나도 없다면
            if i == 17:     # i가 17이면
                continue    # 다음연산
            prime.append(i)     # 그 수는 소수이기에, 소수 리스트에 추가
    
    for i in prime:             # 소수 리스트의 합을 구한다
        ans += i

    return ans


# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(sum_primes(22)) # => 60
    print(sum_primes(33)) # => 143
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    