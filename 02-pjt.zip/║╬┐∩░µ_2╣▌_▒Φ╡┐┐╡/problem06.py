############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def caesar(word, num):
    # pass
    # 여기에 코드를 작성하여 함수를 완성합니다.
    caesar_list = []                # 숫자로 변환된 값 저장 리스트

    for i in word:                  # 단어를 순회하면서
        caesar_num = ord(i) + num   # 단어를 숫자로 변환하고, num 더한다
        if caesar_num > 122:        # 만약 122를 넘는다면
            caesar_num -= 26        # 다시 처음으로 돌아가기 위해 -26
        
        if i.isupper():             # 대문자는 대문자로 반환해야 하니까
            if caesar_num > 90:     # 90넘는 문자는
                caesar_num -= 26    # 다시 -26
                
        caesar_list.append(caesar_num)  # 그리고 그 숫자들을 리스트에 추가

    caesar_word = []                # 다시 문자로 변환한 값 저장 리스트
    for i in caesar_list:           # 숫자 리스트를 순회하면서
        caesar_word.append(chr(i))  # 문자로 변환한 값을 문자 리스트에 저장
    
    ans = ''.join(caesar_word)      # ''구분자로 문자열로 변환
    return ans



# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(caesar('ssafy', 1))   # => ttbgz
    print(caesar('Python', 10)) # => Zidryx
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    