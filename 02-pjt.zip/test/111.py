a = [1,2]
b = [3,4]
c = zip(a,b)

print(c)
print(0x000001DCC70C11C0)
print(list(c))