import my_math

print(my_math.add(1,2))