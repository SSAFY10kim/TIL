# 2023년 7월 싸피 기록

[2023-07-14](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0714.md)  스캠 마지막날 Git branch 개념

[2023-07-16](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0716.md) 알고리즘 풀이 및 언팩킹 오퍼레이터와 애스터리스크(*)

[2023-07-17](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0717.md) 인터프리터, 표현식과 값, 변수

[2023-07-18](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0718.md) **시퀀스타입/비시퀀스타입** , **컬렉션**,형변환,산술,논리,비교,복합 연산자

[2023-07-19](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0719.md) **함수**, 매개변수와 인자, 함수와 Scope, **재귀 함수**, 유용한 함수, **LEGB**

[2023-07-20](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0720.md) **for문, while문,반복제어**,**List comprehension**,pass,**enumerate**

[2023-07-21](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0721.md) 1학기 관통PJT 1주차

[2023-07-24](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0724.md) 데이터구조,**메서드**,str.메서드, list.메서드

[2023-07-25](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0725.md) 데이터구조2, set, dict, copy

[2023-07-26](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0726.md) OOP1, Class, Object, 인스턴스, 메서드, self의 개념

[2023-07-27](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0727.md) Class 상속, super, 다중상속, 에러와 예외처리, 객체지향 특징

[2023-07-28](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0728.md) 1학기 관통PJT 2주차

[2023-07-31](https://github.com/SSAFY10kim/TIL/blob/master/7%EC%9B%94%20TIL/0731.md) 알고리즘 List1, 시간복잡도, 배열, 정렬(버블정렬), 알고리즘 List1 끝
