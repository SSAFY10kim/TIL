# 알고리즘 풀이 현황

### SWEA [12712](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/12712.py) 파리퇴치3  성공

### SWEA [1859](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1859.py) 백만장자 프로젝트 성공

### SWEA [1954](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1954.py) 달팽이 숫자 성공

### SWEA [1204](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1204.py) 최빈수찾기 성공

### SWEA [2001](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/2001.py) 파리퇴치 성공

### SWEA [1926](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1926.py) 간단한 369게임 성공

### SWEA [1979](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1979.py) 어디에 단어가 들어갈 수 있을까 성공

### SWEA [2007](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/2007.py) 패턴 마디의 길이 성공

### SWEA [1209](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1209.py) [S/W 문제해결 기본] 2일차 - Sum 성공

### SWEA [1206](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1206.py) [S/W 문제해결 기본] 1일차 - View 성공

### SWEA [1208](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1208.py) [S/W 문제해결 기본] 1일차 - Flatten 성공

### SWEA [1983](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1983.py) 조교의 성적 매기기 성공

### SWEA [1989](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1989.py) 초심자의 회문검사 성공

### SWEA [1984](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1984.py) 중간 평균값 구하기 성공

### SWEA [1976](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1976.py) 시각 덧셈 성공

### SWEA [1970](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1970.py) 쉬운 거스름돈 성공

### SWEA [1940](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1940.py) 가랏 RC카 성공

### SWEA [1284](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1284.py) 수도 요금 경쟁 성공

### SWEA [2805](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/2805.py) 농작물 수확하기 성공

### SWEA [1289](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/swea_clear/1289.py) 원재의 메모리 복구하기 성공

