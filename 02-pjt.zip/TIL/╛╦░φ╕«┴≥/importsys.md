```
import sys

sys.stdin = open(r'파일 이름(위치까지)','r')

```


# 제출시 주석처리 필수!

