# 백준 알고리즘

### [2563](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/baekjoon_clear/2563.py) 색종이 성공

### [1934](https://github.com/SSAFY10kim/TIL/blob/master/%EC%95%8C%EA%B3%A0%EB%A6%AC%EC%A6%98/baekjoon_clear/1934.py) 최소공배수 성공