name = "김동영"
age = 27

print("나는 ",name,"입니다 ",age,"살 입니다", sep='')   #1

print(f"나는 {name}입니다 {age}살 입니다")              #4

print("나는 {}입니다 {}살 입니다" .format(name, age))   #2

print("나는 %s입니다 %d살 입니다" %(name, age))         #3