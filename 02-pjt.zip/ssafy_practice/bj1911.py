n, l = map(int, input().split())

water = []

for _ in range(n):
    a, b = map(int, input().split())
    water.append((a, b))

water.sort()  # 물웅덩이를 시작 위치 순으로 정렬

end = 0  # 현재까지 흙길을 덮은 위치
count = 0  # 흙길을 덮은 횟수

for a, b in water:
    if end >= b:  # 이미 해당 구간을 다 덮은 경우 건너뜀
        continue
    start = max(end, a)  # 흙길을 덮을 시작 위치
    diff = b - start  # 흙길을 덮을 길이
    needed = (diff + l - 1) // l  # 흙길을 덮는 데 필요한 횟수 (올림)
    count += needed  # 흙길 덮은 횟수 증가
    end = start + needed * l  # 흙길을 덮은 후의 위치 업데이트

print(count)
'''
해당 문제의 로직은 구현했는데 메모리 초과로 다른 로직으로 변경
for문 최대한 자제할 것
'''