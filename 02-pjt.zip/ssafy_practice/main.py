a = [1, 2, 3]

for i in range(len(a)):
    for j in range(len(a)):
        print(a[i][::-1])