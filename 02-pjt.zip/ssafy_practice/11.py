for t in range(1, 11):
    num = int(input())

    arr = [list(map(str, input())) for _ in range(8)]

    # print(arr)    # 입력 검증

    ans = 0
    # 행 검증
    for i in range(8):
        for j in range(8):

            if num % 2 == 0:  # 짝수 검증
                if arr[i][j: j + num // 2] == arr[i][j + num // 2 * 2 - 1: j + num // 2 - 1: -1]:
                    ans += 1

            else:  # 홀수 검증
                if arr[i][j: j + num // 2] == arr[i][j + num // 2 * 2: j + num // 2: -1]:
                    ans += 1

    # print(ans)
    # 열 검증
    for i in range(8):
        for j in range(8):

            if num % 2 == 0:  # 짝수 검증
                if arr[j: j + num // 2][i] == arr[j + num // 2 * 2 - 1: j + num // 2 - 1: -1][i]:
                    ans += 1
            else:
                if arr[j: j + num // 2][i] == arr[j + num // 2 * 2: j + num // 2: -1][i]:
                    ans += 1

    print(f'#{t} {ans}')