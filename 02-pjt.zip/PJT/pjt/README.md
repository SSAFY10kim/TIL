# 관통PJT

관통 프로젝트 명세서 및 예제 코드 저장소입니다.

- 아래 명령어를 이용하여 저장소를 로컬 PC 로 복사하여 활용합니다.
  - 혹은 zip 파일을 다운로드 받아도 괜찮습니다.

```
$ git clone https://lab.ssafy.com/s10/python/pjt.git
```