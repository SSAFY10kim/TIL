import requests
from pprint import pprint


def bestseller_book():
     # 여기에 코드를 작성합니다.  
    URL = 'http://www.aladin.co.kr/ttb/api/ItemSearch.aspx'

    params = {
        'ttbkey': 'ttbhbsowo1413001',
        'Query' : '파울로 코엘료',
        'QueryType': 'Author',
        'MaxResults' : 20,
        'start' : 1,
        'SearchTarget' : 'Book',
        'output' : 'js',
        'Version' : '20131101'
    }

    response = requests.get(URL, params=params).json()

    lst = response['item']
    ans = list(reversed(sorted(lst['salsepoint'])))

    result = []
    count = 0
    for l in ans:
        if count == 5:
            break

        result.append(l['title'])
        count += 1
    
    return result    



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':

    pprint(bestseller_book())

