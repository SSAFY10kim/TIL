a = [3,1,4,2,5]

b = list(reversed(sorted(a)))

print(b)