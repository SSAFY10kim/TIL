T = int(input())            # 테스트케이스 입력

for t in range(1, T+1):     # T 만큼 반복
    N = int(input())        # N개의 정수
    arr = list(map(int, input().split()))   # 길이가 N인 리스트 입력

    sum_lst = []             # 각 시행별 점수 저장할 리스트

    for i in range(1, N+1):  # 1칸부터 N칸씩 점프하는 공을 위한 간격(1~N까지)
        score = 0            # 시행별로 점수 초기화
        for j in range(0, N, i):    # range(a, b, 간격) 이용
            score += arr[j]         # 해당 칸의 점수를 score에 누적합
        sum_lst.append(score)   # 1회 시행 후 리스트에 값 저장

    ans = 0                     # 해당 리스트의 합 반환
    for i in sum_lst:
        ans += i

    if ans <= 0:                # 문제 조건에 점수 합이 0 이하라면
        ans = 0                 # 답은 0
    print(f'#{t} {ans}')

