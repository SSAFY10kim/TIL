T = int(input())

for t in range(1, T+1):
    n = int(input())

    a, b, c, d = map(int, input().split())      # 평탄화 범위

    arr = [list(map(int, input().split())) for _ in range(n)]   # 배열 입력

    avg = 0         # 높이 평균값
    ground = 0      # 전체 땅 높이
    cnt = 0         # 전체 땅 갯수

    for i in range(a, c+1):         # 행 순회
        for j in range(b, d+1):     # 열 순회
            ground += arr[i][j]     # 각 땅의 높이 누적합
            cnt += 1                # 전체 땅 갯수 누적

    avg = ground // cnt             # 높이 평균(목표 높이) 구하기

    ans = 0
    for i in range(a, c+1):         # 다시 행열 순회하면서
        for j in range(b, d+1):
            if arr[i][j] == avg:    # 만약 높이가 이미 평균과 같다면
                continue            # 생략

            while arr[i][j] < avg:  # 평균보다 낮다면
                arr[i][j] += 1      # 평균이 될때까지 한칸씩 증가
                ans += 1            # 횟수 카운트

            while arr[i][j] > avg:  # 평균보다 높다면
                arr[i][j] -= 1      # 평균 될때까지 한칸씩 감소
                ans += 1            # 횟수 카운트

    print(f'#{t} {ans}')            # 누적된 횟수 = ans