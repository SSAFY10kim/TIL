T = int(input())

for t in range(1, T+1):
    eq = list(input())      # 수식 저장
    stack = []              # 연산자 저장 List
    number = []             # 피연산자 저장 List
    ans = 0
    cnt = 0                 # 괄호 안의 숫자
    total = 0               # 전체 숫자 갯수
    flag = True

    if eq[0] not in '({' or eq[-1] not in ')}':     # 가장 앞이나 뒤가 피연산자라면 -1
        print(f'#{t}', -1)
        break
    else:
        for i in eq:
            if i in '({':
                stack.append(i)
                cnt = 0             # 괄호 안 숫자 초기화

            elif i == ')':          # 스택이 비어있거나 괄호 짝이 맞지 않다면 -1
                if len(stack) == 0 or stack[-1] != '(':
                    flag = False
                    break
                elif stack[-1] == '(' and len(stack) == 1:  # 마지막 괄호라면
                    stack.pop()
                    for j in number:    # 남은 모든 피연산자에 대해 연산
                        ans += j
                elif stack[-1] == '(':  # 괄호 짝이 ()로 맞다면
                    stack.pop()         # 괄호 제거
                    if cnt == 1:        # 괄호 안 숫자가 1개라면 생략
                        continue
                    c = 0
                    for j in range(cnt):    # 괄호 안 숫자수 만큼
                        c += number.pop()
                    number.append(c)    # 다시 리스트에 넣어주기
                    cnt = 1
            elif i == '}':          # 스택이 비어있거나 괄호 짝이 맞지 않다면 -1
                if len(stack) == 0 or stack[-1] != '{':
                    flag = False
                    break
                elif stack[-1] == '{' and len(stack) == 1:  # 마지막 괄호라면
                    stack.pop()
                    ans = 1
                    for j in number:    # 남은 모든 피연산자에 대해 연산
                        ans *= j
                elif stack[-1] == '{':  # 괄호 짝이 {}로 맞다면
                    stack.pop()  # 괄호 제거
                    if cnt == 1: # 괄호 안 숫자가 1개라면 생략
                        continue
                    c = 1
                    for j in range(cnt):    # 괄호 안 숫자 수 만큼
                        c *= number.pop()
                    number.append(c)  # 다시 리스트에 넣어주기
                    cnt = 1
            else:
                number.append(int(i))   # i가 피연산자라면 피연산자 리스트에 추가
                total += 1
                cnt += 1
        if flag:                    # -1이 아니라면 연산 결과 출력
            print(f'#{t} {ans}')
        else:                           # 아니면 -1
            print(f'#{t}', -1)