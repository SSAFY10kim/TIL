T = int(input())

di = [-1, 0, 1, 0]
dj = [0, 1, 0, -1]  # 상우하좌

for t in range(1, T+1):
    n = int(input())
    arr = [list(map(int, input().split())) for _ in range(n)]   # 지도 정보
    cnt = 0         # 봉우리 갯수

    for i in range(n):
        for j in range(n):
            flag = True             # 봉우리 확인용 변수
            side = []               # 주변 높이 저장할 List
            pointer = arr[i][j]     # 현재 확인하는 곳의 높이
            for k in range(4):      # 델타 탐색을 이용한 주변 높이 확인
                ni = i + di[k]
                nj = j + dj[k]
                if 0 <= ni < n and 0 <= nj < n:
                    side.append(arr[ni][nj])    # 범위를 벗어나지 않는다면 리스트에 높이 저장

            for s in side:
                if s >= pointer:    # 주변 높이들이 현재 위치보다 높거나 같다면
                    flag = False    # 봉우리가 아니다 즉 False
                    break

            if flag:                # 봉우리가 True라면 봉우리 갯수 +1
                cnt += 1

    print(f'#{t} {cnt}')
